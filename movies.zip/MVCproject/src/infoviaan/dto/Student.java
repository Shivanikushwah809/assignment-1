   package infoviaan.dto;

public class Student {
	private String name;
	private String lactor;
	private String lactress;
	private String ryear;
	private String dname;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLactor() {
		return lactor;
	}
	public void setLactor(String lactor) {
		this.lactor = lactor;
	}
	public Student(String name, String lactor, String lactress, String ryear, String dname) {
		super();
		this.name = name;
		this.lactor = lactor;
		this.lactress = lactress;
		this.ryear = ryear;
		this.dname = dname;
	}
	public String getLactress() {
		return lactress;
	}
	public void setLactress(String lactress) {
		this.lactress = lactress;
	}
	public String getRyear() {
		return ryear;
	}
	public void setRyear(String ryear) {
		this.ryear = ryear;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}



}


