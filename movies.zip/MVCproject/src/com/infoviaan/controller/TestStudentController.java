package com.infoviaan.controller;

import java.util.ArrayList;
import java.util.Scanner;

import com.infoviaan.dao.StudentModel;
import infoviaan.dto.Student;

public class TestStudentController {
	
		

	public static void Show() {
		StudentModel stm = new StudentModel();
		ArrayList<Student> li = stm.getAllStudents();
		System.out.println("------- All Movie Details ----");
		System.out.println("Movie Name\t  Actor \t Actress\t R-Date\t Director\n-----------------------------------------");
		for (Student std : li) {
			System.out.println(std.getName() + "\t " + std.getLactor() + " \t" + std.getLactress() + " \t" + std.getRyear()
					+ "\t " + std.getDname());
		}
		System.out.println("----------------------------------------------");
	}
	
	
	public static void main(String[] args) {
		int choice = 0;
		Scanner sc = new Scanner(System.in);
		do {
			System.out
					.println("Enter 1 for Movie List\n2 for Exit : ");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				Show();;
				break;
				
			}
		} while (choice != 2);
	}

}