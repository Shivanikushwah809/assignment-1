package com.infoviaan.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.ResultSet;

import infoviaan.dto.Student;

public class StudentModel {
	public static Connection start() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/infoviaan", "root", "root");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return con;
	}

		public ArrayList<Student> getAllStudents() {
		ArrayList<Student> al = new ArrayList<Student>();
		Connection con = null;
		try {
			con = start();
			PreparedStatement ps = con.prepareStatement("select * from movie");
			java.sql.ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Student std = new Student(rs.getString("mname"), rs.getString("lactor"), rs.getString("lactress"),
						rs.getString("ryear"), rs.getString("dname"));
				al.add(std);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return al;
	}
	
	}




